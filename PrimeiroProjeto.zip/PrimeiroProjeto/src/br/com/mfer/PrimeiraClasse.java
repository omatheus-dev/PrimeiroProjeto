package br.com.mfer;

public class PrimeiraClasse {

    public static void main (String[] args) {
        System.out.print("Hello World");
    }

}
